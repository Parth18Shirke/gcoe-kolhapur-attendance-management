---
name: Academic Attendance System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#44464f'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#757780'
  outline-variant: '#c5c6d0'
  surface-tint: '#495d8f'
  primary: '#001238'
  on-primary: '#ffffff'
  primary-container: '#0f2756'
  on-primary-container: '#7b8fc5'
  inverse-primary: '#b1c6fe'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#061527'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c2a3c'
  on-tertiary-container: '#8391a7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b1c6fe'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#314576'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#d5e3fc'
  tertiary-fixed-dim: '#b9c7df'
  on-tertiary-fixed: '#0d1c2e'
  on-tertiary-fixed-variant: '#3a485b'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  data-mono:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-desktop: 1.5rem
  gutter-mobile: 1rem
  sidebar-width: 16.5rem
  max-content-width: 90rem
---

## Brand & Style

This design system embodies an authoritative, institutional, and highly accountable operational atmosphere tailored for higher education administration, faculty, and students. The interface communicates administrative clarity, precision, and non-punitive objectivity. 

The aesthetic is **Corporate / Modern Institutional**, prioritizing high-density tabular precision, immediate legibility under varied lighting conditions (e.g., lecture hall projections, mobile devices across campus), and strict accessibility. Visual noise is aggressively minimized in favor of crisp boundaries, distinct typographic scales, and deterministic UI states. Visual hierarchy guides faculty through quick mass-marking workflows and provides students with transparent, verifiable attendance metrics.

## Colors

The palette reinforces institutional integrity, data density, and actionable operational statuses.

### Core Roles
- **Primary (`#0F2756` / `#1E3A8A`)**: Represents institutional authority, primary navigation chrome, master action buttons, and dominant key headings.
- **Secondary (`#3B82F6`)**: Applied to active interactive controls, focus rings, active tab indicators, and contextual drill-down links.
- **Tertiary / Slate Accent (`#475569`)**: Structural iconography, subheadings, and secondary utility triggers.
- **Neutral Surface & Typography**:
  - Root App Canvas: `#F8FAFC` (Slate 50)
  - Card & Container Surface: `#FFFFFF` (Pure White)
  - Primary Content / Headers: `#0F172A` (Slate 900)
  - Primary Body Text: `#334155` (Slate 700)
  - Secondary / Meta / Muted Text: `#64748B` (Slate 500)
  - Structural Borders & Separators: `#E2E8F0` (Slate 200) and `#CBD5E1` (Slate 300)

### Status & Threshold Spectrum
Color must **never** be used alone; all statuses are permanently accompanied by dedicated iconography and explicit text labels to adhere strictly to WCAG 2.1 AA requirements.
- **Compliant / Present (>= 75%)**: Base `#059669` (Emerald 600), Background `#D1FAE5` (Emerald 100), Border `#A7F3D0` (Emerald 200). Paired with checkmark indicator.
- **Warning / At Risk (65% – 74.9%)**: Base `#D97706` (Amber 600), Background `#FEF3C7` (Amber 100), Border `#FDE68A` (Amber 200). Paired with triangle alert indicator.
- **Critical / Absent (< 65%)**: Base `#DC2626` (Red 600), Background `#FEE2E2` (Red 100), Border `#FECACA` (Red 200). Paired with octagon or filled cross indicator.
- **Informational / Excused**: Base `#2563EB` (Blue 600), Background `#EFF6FF` (Blue 50), Border `#BFDBFE` (Blue 200). Paired with info circle.

## Typography

The typographic hierarchy uses `Inter` throughout to optimize horizontal scanning across high-volume administrative tables, metric panels, and student rosters.

### Rules & Formatting
- **Data & Numeric Displays (`data-mono`)**: Roll numbers, student IDs, and raw attendance ratios (e.g., `42 / 48`) use tabular figures (`font-variant-numeric: tabular-nums`) to prevent horizontal jitter during filtering and column sorting.
- **Labels (`label-md`, `label-sm`)**: Used for status pills, table headers, and input micro-labels. Always rendered with uppercase transforms and tracking where specified.
- **Headlines (`headline-lg`, `headline-md`)**: Reserved for academic unit overviews, course titles, and session ledger titles.

## Layout & Spacing

The spatial model relies on a dense 8-point geometric scale (with 4px and 2px micro-increments for high-density administrative controls).

### Layout Structure
- **Desktop (>= 1024px)**: Fixed left vertical navigation bar (`16.5rem` / `264px`), with a fluid content area constrained to a maximum width of `90rem` (`1440px`). Uses a standard 12-column fluid grid system with `1.5rem` (`24px`) gutters and margins.
- **Tablet (768px – 1023px)**: Collapsible compact navigation rail (`4.5rem` / `72px`), fluid 8-column layout with `1.25rem` (`20px`) gutters.
- **Mobile (< 768px)**: 4-column layout with `1rem` (`16px`) outer safe margins. Primary navigation converts to a persistent top institutional app header paired with a bottom sheet or off-canvas drawer. Attendance rosters collapse from multi-column tables to vertical student card stacks.

## Elevation & Depth

This system avoids expressive or dramatic floating shadows, utilizing **low-contrast outlines combined with shallow structural tints** to maintain a crisp administrative feel.

### Elevation Hierarchy
- **Level 0 (Root Canvas)**: Background fill `#F8FAFC`, no border, no shadow.
- **Level 1 (Default Containers & Table Rows)**: `#FFFFFF` surface enclosed by a solid 1px `#E2E8F0` border. Zero elevation blur.
- **Level 2 (Dropdowns, Menus & Filter Panels)**: `#FFFFFF` surface, 1px `#CBD5E1` border, paired with an ambient shadow: `box-shadow: 0 4px 6px -1px rgba(15, 39, 86, 0.06), 0 2px 4px -2px rgba(15, 39, 86, 0.04)`.
- **Level 3 (Modals & Verification Overlays)**: `#FFFFFF` surface, enclosed by 1px `#CBD5E1`, with backdrop blur (`backdrop-filter: blur(4px)`) over a `#0F172A` scrim at 45% opacity. Shadow: `box-shadow: 0 20px 25px -5px rgba(15, 39, 86, 0.12), 0 8px 10px -6px rgba(15, 39, 86, 0.08)`.

## Shapes

The design uses **Soft (`1`)** roundedness to reinforce an orderly, reliable aesthetic:
- **Base Components (Inputs, Buttons, Badges)**: `4px` (`0.25rem`) border-radius.
- **Containers (Cards, Data Panels, Modal Dialogs)**: `8px` (`0.5rem`) border-radius (`rounded-lg`).
- **Segmented Controls & Status Pills**: `6px` (`0.375rem`) border-radius.
- Roundedness should never exceed `8px` except for fully circular avatars and icon buttons (`rounded-full`), avoiding overly casual or consumer-app visual cues.

## Components

### 1. Buttons
- **Primary**: Background `#0F2756`, label `#FFFFFF`, hover `#1E3A8A`, active `#0B1E40`. 4px radius, minimum height 36px (44px on mobile), padding 8px 16px. Focus ring: 2px offset with `#3B82F6`.
- **Secondary / Outline**: Background transparent, border 1px solid `#CBD5E1`, text `#334155`. Hover: background `#F1F5F9`, border `#94A3B8`.
- **Destructive**: Background `#DC2626`, text `#FFFFFF`. Hover: `#B91C1C`.

### 2. Status Chips & Badges
- Always render a leading 6px colored indicator dot or relevant status icon:
  - **Present (>=75%)**: Background `#D1FAE5`, border 1px solid `#A7F3D0`, text `#065F46`.
  - **Warning (65%–74.9%)**: Background `#FEF3C7`, border 1px solid `#FDE68A`, text `#92400E`.
  - **Critical (<65%)**: Background `#FEE2E2`, border 1px solid `#FECACA`, text `#991B1B`.
  - **Excused / Info**: Background `#EFF6FF`, border 1px solid `#BFDBFE`, text `#1E40AF`.
- Text style: `label-sm`, uppercase, semibold.

### 3. Attendance Roster Table & Mass-Action Row
- Header row: `#F1F5F9` background, 1px bottom border `#CBD5E1`, text uppercase `label-md` in `#475569`.
- Student Row: Alternating hover background `#F8FAFC`. Minimum row height: 48px.
- Action Segment: Three-state toggle for each record (Present [P], Absent [A], Excused [E]) rendered as a rigid segmented control with clear borders and immediate toggle visual feedback.

### 4. Distinct Domain Entities
- **Course / Lecture View**: Denotes curriculum blueprint (Course Code, Department, Assigned Faculty, Academic Credits).
- **Attendance Session**: Denotes a specific real-world event (Date, Time Slot, Room Number, Session Status: Draft, Open, Finalized, Locked).
- **Attendance Record**: Represents the individual student audit log belonging to an Attendance Session (Timestamp, Marked By, Verification Method: Biometric, RFID, Manual Faculty Override).

### 5. Input Fields & Form Controls
- Height 38px, background `#FFFFFF`, border 1px solid `#CBD5E1`, text `#0F172A`.
- Focus: Border color `#3B82F6` with a distinct `0 0 0 3px rgba(59, 130, 246, 0.15)` ring.
- Inline validation: Error state uses `#DC2626` border and displays a persistent bottom message with an alert icon.

### 6. Stats Cards
- Metric cards display aggregate course compliance: White background, 1px `#E2E8F0` border, 8px radius.
- Includes clear breakdown of total registered students, total sessions held, average attendance percentage, and count of students in the critical zone.